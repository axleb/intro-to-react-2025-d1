
//
function App() {
  return (
    <>
      <h1>Vite + React</h1>
      <p>
        Lets get Reactive
      </p>
    </>
  )
}
//
export default App
