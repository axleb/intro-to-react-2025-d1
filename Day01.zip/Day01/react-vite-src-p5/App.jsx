import "./styles.css";
import Header from "./components/header";
import Container from "./components/container";
import Footer from "./components/footer";
//
function App() {
  return (
    <>
      <Header />
      <Container />
      <Footer />
    </>
  )
};
//
export default App;
