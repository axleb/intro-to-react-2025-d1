import Aside from "../wrapper/aside";
import Main from "./main";
//
function Container(){
  return (
    <div>
      <Main />
      <Aside />
    </div>
  )
};
//
export default Container
