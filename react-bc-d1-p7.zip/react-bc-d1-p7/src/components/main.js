function Main(){
  return (
    <main>
      <h2>How to Participate in the Program</h2>
      <p> lorem ipsum </p>
    </main>
  )
};
//
export default Main
