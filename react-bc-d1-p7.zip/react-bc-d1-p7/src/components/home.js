import Header from "./header";
import Container from "./container";
import Footer from "./footer";
//
function Home(){
  return (
    <home>
      <Header />
      <Container />
      <Footer />
    </home>
  )
};
//
export default Home;
